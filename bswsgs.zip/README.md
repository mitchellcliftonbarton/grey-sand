# Black Sand White Sand Grey Sand
A Chrome Extension for art.

Feel free to clone this repository and mess around with the code!

When activated, this extension will randomly blur and manipulate your active web page during the day, creating a disruption in your user experience. Don't worry though, this won't completely ruin your web browsing when it happens, as you have the option to rid your web page of all blurriness/disruptions by pressing the "c" key to bring your page back to its natural state without any reloading of the page. This way, if you happen to be posting your latest facebook status or buying something important and the screen all of a sudden becomes too blurry to see what you are doing and you risk losing all the information you already entered in by reloading the page, you can opt out of increasing the blurriness of your page, retain any information that could have been lost, and wait for the next time the extension randomly disrupts your browsing. Although because all websites are different, there is a slim chance this might not always work, as some websites might reload on their own.

For optimal experience with the extension, I suggest forgetting that you installed it, and letting it do its work.

The blurry images created by the extension are displayed at http://banalbanal.org/bb0005.html.
